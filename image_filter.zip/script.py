# Image Filter
# By k8thekat - 4/10/2021
# Touched gently...then a bit roughly by EventHorizon01 - 4/26/2021
import os
import sys
from PIL import Image
import hashlib
import pathlib

# Changelog
# Remove path import as you're already importing os AND you're using a var named "path". This can break imports as your var will overwrite the module
# 
# Renamed function/vars
# As you've done some java, you've already been exposed to camelcasing, but python's standard is to underscores which i highly vibe with so i've renamed most of functions/vars
# More info on the accepted answer here: https://stackoverflow.com/questions/8908760/should-i-use-camel-case-or-underscores-in-python
# 
# Changed while loop to use boolean vs int for clarity/maintanability
# 
# Format code to be arranged in sections: Vars, functions, main execution blocks
# Much like java/.net, it's preferrable to have vars at the top, then all definitions (since they must be defined prior to being called), then your main execution block
# I actually explicitly define my main function as described here but that's personal preference: https://realpython.com/python-main-function/
#
# Refactored user_get_path
    # changed 'loc' to msg for clarity
    # defined var to be returned at beginning of function (also renamed to something other than 'path')
    # changed if checks to be if,elif,else for efficiency
    # changed default check to a 'is None': https://towardsdatascience.com/python-the-boolean-confusion-f7fc5288f0ce
    # changed exists check to a isdir check, to avoid file path input from breaking script

# Refactored confirm func & more
    # I started struggling to review the code here due to several vars not telling me what they were doing: alist, defans, entry, etc are all very undescriptive
    # It seems you changed the confirm funct from being a deletion of dups to a renaming of dups, then pulled the renaming back out into your main while loop (it's early for me so i might be mistaken)

    # I also had the read the entire script just to refactor this method, this speaks to the scripts design needing more work

    # Renamed func for clarity, func names should tell you what it's doing without having to read the code
    # Made several changes to clarity what the script is doing and what the vars are holding
        # alist     > file_list
        # path_in   > dir_src
        # path_out  > dir_dest
        # entry     > filename
        
    # Moved the destination dir creation to a function instead of having a large code block in the main execution area

# Refactored main while loop
    # More variable renames. Keep in mind sometimes you use a script for years before having to edit it again, spending the time now to type out img_width vs IMW will save you time in the future
    # Moved res index logic to it's own function
        # Functions are a logical grouping of code that, when done right, perform a single task
    # I've noticed your loop variable names are odd. Best to keep them super simple and super descriptive
        # For example, for file in files, or for dir in dirs, for index in array
    # Added finally block to close resourced, previous way would have left img open if an error was encountered
    # Changed the "found" boolean to use another var. Same principle but with the code moved to a def, it's job now is to "get me the index of this files resolution"
    # Changed ignored files process, now uses an inclusion system vs an exclusion one; complete with new module, vars and defs to support it
    # Changed the file move/rename process to not rely on failure for dup checking
    # Added check for if filelist is empty, then don't run anything

# TODO
    # All try catches should catch specific errors and handle them correctly
    # Allow passing the dirs into the script as args, and if you do, then don't prompt user
    # Enhance the image resolution checking to not default to last index if height/width check fails
    # Make a special easter egg that prints some sexy ascii art ;)

# --------------------------------------- Vars -------------------------------------------- #
dir_src = None
dir_dest = None
file_list = None
# IMG_RES Dictionary
IMG_RES = [
    {"name": "Low Res",      "dimensions":   (1440, 900)}, 
    {"name": "Mid Res",      "dimensions":   (1920, 1440)},
    {"name": "High Res",     "dimensions":   (2560, 1600)},
    {"name": "UHD Res",      "dimensions":   (3840, 2160)},
    {"name": "Phone Res",    "dimensions":   (1080, 2400)},
    {"name": "UHDP Res",     "dimensions":   (0,0)}]
allowed_img_extensions = ['.jpg', '.jpeg', '.png', '.gif']
# --------------------------------------- Functions --------------------------------------- #
# User path input function loop
def get_user_dir_path(msg):
    default_path = "d:/picture/anime"
    root_dir = None
    prompt = "Enter " + msg + " File Path (press enter to use default: " + default_path + "): "
    while True:
        user_input = input(prompt)

        # Validate user input
        if user_input is None:
            root_dir = default_path
            break
        elif os.path.isdir(user_input):
            root_dir = user_input
            break
        else:
            print("Invalid path and/or input of '" + user_input + "', try again...")
    
    print(msg + " Path set to " + root_dir)
    
    return root_dir

def parse_file_list(file_list):
    cleaned_files = []
    for file in file_list:
        if pathlib.Path(file).suffix in allowed_img_extensions:
            cleaned_files.append(file)
    return cleaned_files

# Deletion confirmation loop
def prompt_for_dup_file(src_dir, filename):
    # you don't need a 'default' for vars, just set your target var to the default value and only update it if/when needed
    user_input = input("Do you want to rename the duplicate file? " + os.path.join(src_dir, filename) + "(y/N)?")

    # this is the perfect example to use a Ternary operation, specifically usefuel when you're doing an if/else type operation where you set a value based on the boolean logic
    # main advantage here is clarity and space savings, but it can be really confusing for noobs but is used all the time once you get familiar with them
    # https://book.pythontips.com/en/latest/ternary_operators.html
    answer = 'n' if user_input.lower() in [None, 'n'] else 'y'
    return answer

# Resolution folder creation
def create_output_dirs():
    for res in IMG_RES:
        res_name = res['name']
        # When doing logical checks, try to do what you'd do irl, aka lets say you're looking for something.
        # You go look for it, is this here? if not, then next place...
        # Coding is all about modeling the real world so when you do a process, keeping it inline with how you think/do things
        new_res_dir = pathlib.Path(dir_dest, res_name)
        if os.path.isdir(new_res_dir):
            print("Found " + res_name + " directory; skipping creation")
        else:
            os.makedirs(new_res_dir)
            print(res_name + " folder created!")

def find_image_resolution_index(filepath):
    # image sorting via dictionary dimensions comparison" > = GREATER THAN | < = LESS THAN "
    # Quick tip about gt/lt is the arrow is a mouth, and always eats the bigger number!
    img = None
    img_index = None
    try:
        img = Image.open(filepath)
        for index in range(0, len(IMG_RES) - 1): # range function starts at X value and ends at Y-1 (range(X,Y-1)) count = interation value
            img_width, img_hight = IMG_RES[index]["dimensions"] # value 1, value 2 = IMG_RES[int][dictionary key]
            if (img_width >= img.width) and (img_hight >= img.height):
                img_index = index
                print( img.width, "X", img.height, "|", filepath, ">> " + IMG_RES[index]["name"])
                break

    except:
        pass
    else:
        img.close()
    
    # if image doesn't fit any dictionary values place in UHDP folder
    if not img_index:
        img_index = len(IMG_RES) - 1 # this breaks the expandability of your dict :(

    return img_index

# if duplicate file exists; compare via hashlib.sha256 in binary format
def is_duplicate_image(src_file, dest_file):
    is_dup_img = False
    # Compare file hashes, if same, delete source file, else rename dest file w/ int suffix
    file1_hash = hashlib.sha256(open(src_file, "rb").read()).hexdigest() # file hash comparison => open(file), "rb" = read binary , read file and digest = hash results
    file2_hash = hashlib.sha256(open(dest_file,"rb").read()).hexdigest()

    # compare file1_hash to file2_hash
    if file1_hash == file2_hash:
        print(dir_src + filename)
        print(file1_hash + "\n" + file2_hash)
        is_dup_img = True

    return is_dup_img

def get_next_filename(src_file):
    # duplicate file name check and renaming
    extension_dot_index = dest_file.rfind(".")
    new_img_suffix = 2

    while(os.path.exists(dest_file[0:extension_dot_index] + str(new_img_suffix) + dest_file[extension_dot_index:])):
        new_img_suffix += 1   

    print("Duplicate file name found at " + dest_file + " --> Renaming file..." + dest_file[0:extension_dot_index] + str(new_img_suffix) + dest_file[extension_dot_index:])
    return dest_file[0:extension_dot_index] + str(new_img_suffix) + dest_file[extension_dot_index:]

# image filtering
def filter_images(file_list):
    for file in file_list:
        src_file  = pathlib.Path(dir_src, file)
        # Resolution index determines destination dir's name based on IMG_RES name keys   
        res_index = find_image_resolution_index(src_file)

        dest_file = pathlib.Path(dir_dest, IMG_RES[res_index]["name"], file)
        
        # Check if destination file already exists
        if os.path.exists(dest_file):
            if is_duplicate_image(src_file, dest_file):
                # Prompt confirmation for deletion
                prompt_for_dup_file(dir_src, file)
            else:
                new_filename = get_next_filename(src_file)
                dest_file = pathlib.Path(dir_dest, IMG_RES[res_index]["name"], new_filename)
                os.rename(src_file, dest_file)
        else:
            # file moving to new location via os.rename(source, new) function
            os.rename(src_file, dest_file)

# --------------------------------------- Main -------------------------------------------- #
# User path prompt
dir_src     = get_user_dir_path("Source")
dir_dest    = get_user_dir_path("Destination")

# create list of filenames from the given dir
file_list = os.listdir(dir_src)

# Removes files w/ extensions not in allowed_img_extensions
file_list = parse_file_list(file_list)

if file_list is not None:
    create_output_dirs()
    filter_images(file_list)