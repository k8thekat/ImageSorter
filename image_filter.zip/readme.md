# Install pip
`sudo apt install python3-pip`

# Using Requirements Files
https://realpython.com/lessons/using-requirement-files/

# Run Script
python3 script.py
